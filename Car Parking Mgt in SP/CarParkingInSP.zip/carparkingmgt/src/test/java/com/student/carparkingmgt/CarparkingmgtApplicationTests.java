package com.student.carparkingmgt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarparkingmgtApplicationTests {

	@Test
	void contextLoads() {
	}

}
