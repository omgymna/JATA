package com.student.carparkingmgt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarparkingmgtApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarparkingmgtApplication.class, args);
	}

}
